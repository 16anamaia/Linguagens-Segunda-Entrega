package Menuloteria;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.util.Scanner;
import java.lab;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ApostasAaZ extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Apostas de A a Z");

        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        Label label = new Label("Escolha uma letra de A a Z:");
        TextField textField = new TextField();
        Button button = new Button("Apostar");
        Label resultadoLabel = new Label();

        button.setOnAction(event -> {
            String aposta = textField.getText().toUpperCase();
            if (aposta.length() == 1 && aposta.matches("[A-Z]")) {
                resultadoLabel.setText("Aposta em " + aposta + " bem-sucedida!");
            } else {
                resultadoLabel.setText("Aposta inválida. Escolha uma letra de A a Z.");
            }
        });

        gridPane.add(label, 0, 0);
        gridPane.add(textField, 1, 0);
        gridPane.add(button, 2, 0);
        gridPane.add(resultadoLabel, 0, 1, 3, 1);

        Scene scene = new Scene(gridPane, 300, 100);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
