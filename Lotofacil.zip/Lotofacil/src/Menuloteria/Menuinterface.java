package Menuloteria;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

public class Menuinterface {
    private static int[] numerosSorteados = new int[6];
    private static int[] numerosApostados;
    private static int quantidadeNumeros;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Menu da Loteria");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            JPanel menuPanel = new JPanel(new FlowLayout());
            JButton fazerApostaButton = new JButton("Fazer uma aposta");
            JButton verificarResultadosButton = new JButton("Verificar resultados");

            fazerApostaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fazerAposta();
                }
            });

            verificarResultadosButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    verificarApostas();
                }
            });

            menuPanel.add(fazerApostaButton);
            menuPanel.add(verificarResultadosButton);

            frame.add(menuPanel, BorderLayout.CENTER);
            frame.pack();
            frame.setVisible(true);
        });
    }

    public static void fazerAposta() {
        JFrame apostaFrame = new JFrame("Fazer uma aposta");
        apostaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        apostaFrame.setLayout(new BorderLayout());

        JPanel numerosPanel = new JPanel(new GridLayout(0, 1));
        JLabel label = new JLabel("Digite os números da sua aposta:");
        numerosPanel.add(label);

        quantidadeNumeros = 6;
        numerosApostados = new int[quantidadeNumeros];

        for (int i = 0; i < quantidadeNumeros; i++) {
            JPanel inputPanel = new JPanel(new FlowLayout());
            JLabel numeroLabel = new JLabel((i + 1) + "º número:");
            JTextField numeroTextField = new JTextField(5);
            inputPanel.add(numeroLabel);
            inputPanel.add(numeroTextField);
            numerosPanel.add(inputPanel);

            int finalI = i;
            numeroTextField.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        int numero = Integer.parseInt(numeroTextField.getText());
                        numerosApostados[finalI] = numero;
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(apostaFrame, "Digite um número válido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }

        JButton fazerApostaButton = new JButton("Fazer Aposta");
        fazerApostaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                apostaFrame.dispose();
                fazerAposta();
            }
        });

        numerosPanel.add(fazerApostaButton);

        apostaFrame.add(numerosPanel, BorderLayout.CENTER);
        apostaFrame.pack();
        apostaFrame.setVisible(true);
    }

    public static void verificarApostas() {
        JFrame resultadosFrame = new JFrame("Verificar resultados");
        resultadosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resultadosFrame.setLayout(new BorderLayout());

        JPanel resultadosPanel = new JPanel(new GridLayout(0, 1));

        if (numerosSorteados[0] == 0) {
            JOptionPane.showMessageDialog(resultadosFrame, "Números sorteados ainda não estão disponíveis.", "Aviso", JOptionPane.WARNING_MESSAGE);
            resultadosFrame.dispose();
            return;
        }

        JLabel numerosSorteadosLabel = new JLabel("Números sorteados: " + Arrays.toString(numerosSorteados));
        JLabel resultadoLabel;

        int numerosCorretos = 0;
        for (int numeroApostado : numerosApostados) {
            for (int numeroSorteado : numerosSorteados) {
                if (numeroApostado == numeroSorteado) {
                    numerosCorretos++;
                    break;
                }
            }
        }

        if (numerosCorretos == quantidadeNumeros) {
            resultadoLabel = new JLabel("Parabéns! Você ganhou R$ 1.000,00 reais.");
        } else {
            resultadoLabel = new JLabel("Que pena! O número sorteado foi: " + Arrays.toString(numerosSorteados));
        }

        resultadosPanel.add(numerosSorteadosLabel);
        resultadosPanel.add(resultadoLabel);

        resultadosFrame.add(resultadosPanel, BorderLayout.CENTER);
        resultadosFrame.pack();
        resultadosFrame.setVisible(true);
    }
}
