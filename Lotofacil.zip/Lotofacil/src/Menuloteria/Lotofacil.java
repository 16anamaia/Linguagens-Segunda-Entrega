package Menuloteria;

import java.util.Random;
import java.util.Scanner;

public class Lotofacil {
    private static int[] numerosSorteados = new int[6];
    private static int[] numerosApostados;
    private static int quantidadeNumeros;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            exibirMenu();
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    Object fazerAposta;;
                    break;
                case 2:
                    Object verificarAposta;
                    break;
                case 0:
                    System.out.println("Saindo do programa. Obrigado por jogar!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 0);

        scanner.close();
    }

    private static void verificarAposta() {
    }

    public static void exibirMenu() {
        System.out.println("==== Menu da Loteria ====");
        System.out.println("1. Fazer uma aposta");
        System.out.println("2. Verificar resultados");
        System.out.println("0. Sair");
        System.out.print("Digite a opção desejada: ");
    }

    public static void fazerAposta () {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("== Fazer uma aposta ==");

            quantidadeNumeros = 6;
            numerosApostados = new int[quantidadeNumeros];

            System.out.println("Digite os números da sua aposta:");
            for (int i = 0; i < quantidadeNumeros; i++) {
                System.out.print("Digite o " + (i + 1) + "º número: ");
                numerosApostados[i] = scanner.nextInt();
            }
        }

        System.out.print("Aposta realizada: ");
        for (int numero : numerosApostados) {
            System.out.print(numero + " ");
        }
        System.out.println("\nAposta realizada com sucesso!");

        Random random = new Random();
        for (int i = 0; i < quantidadeNumeros; i++) {
            numerosSorteados[i] = random.nextInt(60) + 1;
        }
    }

    public static void verificarApostas () {
        System.out.println("== Verificar resultados ==");

        // Exiba os números sorteados.
        System.out.print("Números sorteados: ");
        for (int numeroSorteado : numerosSorteados) {
            System.out.print(numeroSorteado + " ");
        }
        System.out.println();

        int numerosCorretos = 0;
        for (int numeroApostado : numerosApostados) {
            for (int numeroSorteado : numerosSorteados) {
                if (numeroApostado == numeroSorteado) {
                    numerosCorretos++;
                    break;
                }
            }
        }
        System.out.println("Números corretos: " + numerosCorretos);
    }

}




